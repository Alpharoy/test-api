<?php

namespace Urland\Exceptions\Client;

use Urland\Exceptions\BaseException as ParentException;

/**
 * Class BaseException
 *
 * @package Urland\Exceptions\Client
 */
class BaseException extends ParentException
{

}
