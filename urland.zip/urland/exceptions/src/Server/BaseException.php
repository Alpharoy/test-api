<?php

namespace Urland\Exceptions\Server;

use Urland\Exceptions\BaseException as ParentException;

/**
 * Class BaseException
 *
 * @package Urland\Exceptions\Server
 */
class BaseException extends ParentException
{

}
