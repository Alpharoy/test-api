<?php

namespace Urland\Area;

use Urland\Exceptions\Client\BadRequestException;

/**
 * Class Area
 *
 * @package Urland\Area
 *
 * @property-read string $code
 * @property-read string $name
 * @property-read string $parentCode
 * @property-read int    $level
 * @property-read string $levelKey
 * @property-read bool   $isLast
 * @property-read bool   $isDeleted
 * @property-read Area   $parent
 * @property-read Area[] $children
 */
class Area
{
    /**
     *
     * @var array
     */
    protected static $levelKeys = [
        1 => 'country',
        2 => 'province',
        3 => 'city',
        4 => 'district',
        5 => 'town',
    ];

    /**
     * @var static
     */
    protected $parent = null;

    /**
     * @var static[]
     */
    protected $children = [];

    /**
     * @var string
     */
    protected $code;

    /**
     * @var string
     */
    protected $name;

    /**
     * @var string
     */
    protected $parentCode;

    /**
     * @var int
     */
    protected $level;

    /**
     * @var string
     */
    protected $levelKey;

    /**
     * @var bool
     */
    protected $isLast;

    /**
     * @var bool
     */
    protected $isDeleted;

    /**
     * @var \Urland\Area\AreaFamily|null
     */
    protected $family;

    /**
     * Area constructor.
     *
     * @param string $code
     * @param string $name
     * @param string $parentCode
     * @param int    $level
     * @param bool   $isLast
     * @param bool   $isDeleted
     */
    public function __construct($code, $name, $parentCode, $level, $isLast, $isDeleted = false)
    {
        $this->code       = $code;
        $this->name       = $name;
        $this->parentCode = $parentCode;
        $this->level      = $level;
        $this->levelKey   = static::$levelKeys[$level];
        $this->isLast     = $isLast;
        $this->isDeleted  = $isDeleted;
    }

    /**
     * 获取当前地址全名
     *
     * @return string
     */
    public function getFullName()
    {
        $fullName = '';
        $parent   = $this;
        while ($parent->level > 1) {
            $fullName = $parent->name . $fullName;
            $parent   = $parent->parent;
        }
        return $fullName;
    }

    /**
     * @param \Urland\Area\Area $area
     *
     * @return $this
     */
    public function setParent(Area $area)
    {
        $this->parent = $area;
        return $this;
    }

    /**
     * @param array $children
     *
     * @return $this
     */
    public function setChildren(array $children)
    {
        $this->children = $children;
        return $this;
    }

    /**
     * @param \Urland\Area\Area $area
     *
     * @return $this
     */
    public function addChild(Area $area)
    {
        array_push($this->children, $area);
        return $this;
    }

    /**
     * @param \Urland\Area\Area $area
     *
     * @return $this
     */
    public function removeChild(Area $area)
    {
        $key = array_search($area, $this->children, true);
        if ($key !== false) {
            array_splice($this->children, $key, 1);
        }
        return $this;
    }

    /**
     * 根据地址名称搜索子级地址
     *
     * @param string $areaName
     *
     * @return null|\Urland\Area\Area
     */
    public function getChildByName($areaName)
    {
        foreach ($this->children as $child) {
            if ($child->name === $areaName) {
                return $child;
            }
        }
        return null;
    }

    /**
     * 获取当前地址父子级所有信息
     *
     * @return \Urland\Area\AreaFamily
     */
    public function getFamily()
    {
        if ($this->family) {
            return $this->family;
        }

        return $this->family = new AreaFamily($this);
    }

    /**
     * 判断当前地址是否最后一级地址，或者在某个level内的地址
     *
     * @param int                    $orLessThanLevel
     * @param \RuntimeException|null $exception
     *
     * @return $this
     */
    public function throwIfNotLast($orLessThanLevel = 99, \RuntimeException $exception = null)
    {
        if ($this->isLast || $this->level >= $orLessThanLevel) {
            return $this;
        }

        if (!$exception) {
            $exception = new BadRequestException('请再选择下一级地址');
        }

        throw $exception;
    }

    /**
     * @param string $name
     *
     * @return mixed
     */
    public function __get($name)
    {
        if (property_exists($this, $name)) {
            return $this->{$name};
        }

        user_error('Undefined property: ' . get_class($this) . '::$' . $name);
        return null;
    }

    /**
     * @param string $name
     *
     * @return bool
     */
    public function __isset($name)
    {
        return isset($this->{$name});
    }
}
