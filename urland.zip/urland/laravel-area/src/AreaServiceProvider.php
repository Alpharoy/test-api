<?php

namespace Urland\Area;

use Illuminate\Support\ServiceProvider;
use Urland\Area\Console\AreaCacheCommand;
use Urland\Area\Console\AreaClearCommand;

class AreaServiceProvider extends ServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = true;

    /**
     * Bootstrap the application urland area.
     *
     * @return void
     */
    public function boot()
    {
        // 配置发布
        if ($this->app->runningInConsole()) {
            $this->publishes([
                __DIR__ . '/../config/area.php' => config_path('area.php'),
            ], 'urland-area');
        }
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        // 配置文件
        $configPath = __DIR__ . '/../config/area.php';
        $this->mergeConfigFrom($configPath, 'area');

        $this->app->singleton('area', function ($app) {
            $areaConfig = $app['config']['area'];

            return new AreaManager($areaConfig, $app['cache.store']);
        });

        // 注册控制台命令
        $this->registerCommands();
    }

    /**
     * 注册控制台命令
     */
    protected function registerCommands()
    {
        $this->app->singleton('command.area.cache', function ($app) {
            return new AreaCacheCommand($app['area']);
        });

        $this->app->singleton('command.area.clear', function ($app) {
            return new AreaClearCommand($app['area']);
        });

        $this->commands([
            'command.area.cache',
            'command.area.clear',
        ]);
    }

    /**
     * Get the config path
     *
     * @return string
     */
    protected function getConfigPath()
    {
        return config_path('area.php');
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [
            'area',
            'command.area.cache',
            'command.area.clear',
        ];
    }
}