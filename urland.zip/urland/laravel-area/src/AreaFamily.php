<?php

namespace Urland\Area;

/**
 * Class AreaFamily
 *
 * @package Urland\Area
 *
 * @property-read \Urland\Area\Area      $current
 * @property-read \Urland\Area\Area|null $country
 * @property-read \Urland\Area\Area|null $province
 * @property-read \Urland\Area\Area|null $city
 * @property-read \Urland\Area\Area|null $district
 * @property-read \Urland\Area\Area|null $town
 */
class AreaFamily
{
    /**
     * @var \Urland\Area\Area
     */
    protected $current;

    /**
     * @var \Urland\Area\Area|null
     */
    protected $country = null;

    /**
     * @var \Urland\Area\Area|null
     */
    protected $province = null;

    /**
     * @var \Urland\Area\Area|null
     */
    protected $city = null;

    /**
     * @var \Urland\Area\Area|null
     */
    protected $district = null;

    /**
     * @var \Urland\Area\Area
     */
    protected $town = null;

    /**
     * @var \Urland\Area\Area[]
     */
    protected $areas = [];

    /**
     * AreaFamily constructor.
     *
     * @param \Urland\Area\Area $area
     */
    public function __construct(Area $area)
    {
        $this->current = $area;

        $tmpArea = $area;
        while ($tmpArea) {
            $this->areas[$tmpArea->level] = $tmpArea;

            $key          = $tmpArea->levelKey;
            $this->{$key} = $tmpArea;
            $tmpArea      = $tmpArea->parent;
        }

        ksort($this->areas);
    }

    /**
     * 根据level获取对应的区域
     *
     * @param int $level
     *
     * @return null|\Urland\Area\Area
     */
    public function getAreaByLevel($level)
    {
        return $this->areas[$level] ?? null;
    }

    /**
     * 获取区域列表
     *
     * @return \Urland\Area\Area[]
     */
    public function getAreas()
    {
        return $this->areas;
    }

    /**
     * 获取区域列表某个值
     *
     * @param string $key
     *
     * @return array
     */
    public function getAreasValue($key)
    {
        $results = [];
        foreach ($this->areas as $level => $area) {
            $results[$level] = $area->{$key};
        }

        return $results;
    }

    /**
     * @param string $name
     *
     * @return mixed
     */
    public function __get($name)
    {
        if (property_exists($this, $name)) {
            return $this->{$name};
        }

        user_error('Undefined property: ' . get_class($this) . '::$' . $name);
        return null;
    }

    /**
     * @param string $name
     *
     * @return bool
     */
    public function __isset($name)
    {
        return isset($this->{$name});
    }
}
