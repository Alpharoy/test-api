<?php

namespace Urland\Area;

/**
 * Class AreaFull
 *
 * @package Urland\Area
 *
 * @property-read \Urland\Area\Area $area
 * @property-read string|null       $detail
 */
class AreaFull
{
    /**
     * 全地址所在省市区
     *
     * @var \Urland\Area\Area
     */
    protected $area;

    /**
     * 详细地址
     *
     * @var string
     */
    protected $detail;

    /**
     * AreaFull constructor.
     *
     * @param \Urland\Area\Area $area
     * @param string|null       $detail
     */
    public function __construct(Area $area, $detail)
    {
        $this->area   = $area;
        $this->detail = $detail;
    }

    /**
     * 获取全路径
     *
     * @return string
     */
    public function getFullAddress()
    {
        return $this->area->getFullName() . $this->detail;
    }

    /**
     * @param string $name
     *
     * @return mixed
     */
    public function __get($name)
    {
        if (property_exists($this, $name)) {
            return $this->{$name};
        }

        user_error('Undefined property: ' . get_class($this) . '::$' . $name);
        return null;
    }

    /**
     * @param string $name
     *
     * @return bool
     */
    public function __isset($name)
    {
        return isset($this->{$name});
    }
}