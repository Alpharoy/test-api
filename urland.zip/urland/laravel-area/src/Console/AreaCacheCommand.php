<?php

namespace Urland\Area\Console;

use Illuminate\Console\Command;
use Urland\Area\AreaContainer;
use Urland\Area\AreaManager;

class AreaCacheCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'area:cache';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cache areas from remote server.';

    /**
     * The area container instance.
     *
     * @var \Urland\Area\AreaManager
     */
    protected $container;

    /**
     * @var string
     */
    protected $path;

    /**
     * Create a new area cache command instance.
     *
     * @param \Urland\Area\AreaContainer $container
     */
    public function __construct(AreaManager $manager)
    {
        parent::__construct();

        $this->manager = $manager;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $this->call('area:clear');

        $this->manager->clearCache();

        $this->info('Area cached successfully!');
    }
}
