<?php

namespace Urland\Area\Console;

use Illuminate\Console\Command;
use Urland\Area\AreaManager;

class AreaClearCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'area:clear';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Clear the areas cache.';

    /**
     * @var \Urland\Area\AreaManager
     */
    protected $manager;

    /**
     * Create a new area clear command instance.
     *
     * @param \Urland\Area\AreaManager $manager
     */
    public function __construct(AreaManager $manager)
    {
        parent::__construct();

        $this->manager = $manager;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $this->manager->clearCache();

        $this->info('Area cache cleared!');
    }
}
