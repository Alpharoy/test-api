<?php

namespace Urland\Area;

use Illuminate\Cache\Repository as Cache;
use Illuminate\Support\Arr;
use Urland\ApiClient\Client;
use Urland\Exceptions\Client\NotFoundException;
use Urland\Exceptions\Server\InternalServerException;

class AreaManager
{
    /**
     * @var string
     */
    protected $apiKey;

    /**
     * @var string
     */
    protected $apiSecret;

    /**
     * @var string
     */
    protected $baseUri;

    /**
     * @var string
     */
    protected $publicBaseUri;

    /**
     * @var \Urland\ApiClient\Client
     */
    protected $client;

    /**
     * @var \Urland\ApiClient\Client
     */
    protected $publicClient;

    /**
     * @var \Illuminate\Cache\Repository
     */
    protected $cache;

    /**
     * 缓存前缀
     *
     * @var string
     */
    protected $cachePrefix;

    /**
     * @var \Urland\Area\Area
     */
    protected $chinaArea;

    /**
     * @var \Urland\Area\Area[]
     */
    protected $codedAreas;

    /**
     * AreaContainer constructor.
     *
     * @param array                        $config
     * @param \Illuminate\Cache\Repository $cache
     */
    public function __construct($config, Cache $cache)
    {
        $this->apiKey        = Arr::get($config, 'api_key');
        $this->apiSecret     = Arr::get($config, 'api_secret');
        $this->baseUri       = Arr::get($config, 'base_uri') . '/internal-api/v1/';
        $this->publicBaseUri = Arr::get($config, 'public_base_uri') . '/api/v1/';
        $this->cachePrefix   = Arr::get($config, 'cache_prefix', 'area');
        $this->cache         = $cache;

        $chinaArea = new Area('1', '全国', null, 1, false);

        $this->chinaArea  = $chinaArea;
        $this->codedAreas = [$chinaArea->code => $chinaArea];
    }

    /**
     * 缓存数据
     *
     * @return array
     */
    public function cache()
    {
        return $this->getCompressedAreas();
    }

    /**
     * 清理缓存
     *
     * @return $this
     */
    public function clearCache()
    {
        $cachedKey = $this->cacheKey('areas_compressed');

        $this->cache->forget($cachedKey);
        return $this;
    }

    /**
     * 获取顶级全国 Area
     *
     * @return \Urland\Area\Area
     */
    public function getChinaArea()
    {
        $this->initAreas();
        return $this->chinaArea;
    }

    /**
     * 通过地址code获取地址信息
     *
     * @param string $code
     * @param bool   $throwException
     *
     * @return \Urland\Area\Area|null
     * @throws \Urland\Exceptions\Client\NotFoundException
     */
    public function getAreaByCode($code, $throwException = true)
    {
        $this->initAreas();
        if (isset($this->codedAreas[$code])) {
            return $this->codedAreas[$code];
        }

        if ($throwException) {
            throw new NotFoundException('获取地址信息失败');
        }

        return null;
    }

    /**
     * 通过地址名称获取地址信息
     *
     * @param string[] $names
     * @param bool     $throwException
     *
     * @return \Urland\Area\Area|null
     * @throws \Urland\Exceptions\Client\NotFoundException
     */
    public function getAreaByNames($names, $throwException = true)
    {
        $this->initAreas();

        $area = array_reduce(array_filter($names), function ($parentArea, $name) {
            return $parentArea ? $parentArea->getChildByName($name) : null;
        }, $this->chinaArea);

        if (!$area && $throwException) {
            throw new NotFoundException('获取地址信息失败');
        }

        return $area;
    }

    /**
     * 获取省份列表
     *
     * @return \Urland\Area\Area[]
     */
    public function provinceAreas()
    {
        $this->initAreas();
        return $this->chinaArea->children;
    }

    /**
     * 通过地址服务器解析完整地址
     *
     * @param string $fullAddress
     *
     * @return \Urland\Area\AreaFull
     */
    public function parseFullAddress($fullAddress)
    {
        $result = $this->client()->get('area-parses', [
            'address'   => $fullAddress,
            'min_level' => 0,
        ])->getJson();

        $area   = $this->getAreaByCode(Arr::get($result, 'code'));
        $detail = Arr::get($result, 'detail_address', '');

        return new AreaFull($area, $detail);
    }

    /**
     * 初始化解析地址库
     */
    protected function initAreas()
    {
        if (count($this->codedAreas) > 1) {
            return;
        }

        $codedAreas = $this->codedAreas;
        foreach ($this->getCompressedAreas() as $compressArea) {
            $area = new Area(...$compressArea);

            $codedAreas[$area->code] = $area;
        }

        // 处理子父级
        foreach ($codedAreas as $area) {
            if (!$area->parentCode) {
                continue;
            }

            $parentArea = $codedAreas[$area->parentCode];
            $parentArea->addChild($area);
            $area->setParent($parentArea);
        }

        $this->codedAreas = $codedAreas;
    }

    /**
     * 公共接口client
     *
     * @return \Urland\ApiClient\Client
     */
    protected function publicClient()
    {
        if ($this->publicClient) {
            return $this->publicClient;
        }
        return $this->publicClient = new Client(['base_uri' => $this->publicBaseUri]);
    }

    /**
     * 内部接口client
     *
     * @return \Urland\ApiClient\Client
     */
    protected function client()
    {
        if ($this->client) {
            return $this->client;
        }

        $options = [
            'api_sign'   => true,
            'api_key'    => $this->apiKey,
            'api_secret' => $this->apiSecret,
            'base_uri'   => $this->baseUri,
        ];

        return $this->client = new Client($options);
    }

    /**
     * 获取缓存key
     *
     * @param string $name
     *
     * @return string
     */
    protected function cacheKey($name)
    {
        return $this->cachePrefix . '::' . $name;
    }

    /**
     * 获取压缩后的地址信息
     *
     * @return array
     */
    protected function getCompressedAreas()
    {
        $areasCacheKey   = $this->cacheKey('areas_compressed');
        $checkedCacheKey = $this->cacheKey('areas_checked');
        if ($this->cache->get($checkedCacheKey)) {
            $compressedAreas = $this->cache->get($areasCacheKey);
            if ($compressedAreas) {
                return $compressedAreas;
            }
        }

        // 检查服务器时间是否与本地一致
        $timeCacheKey     = $this->cacheKey('areas_update_time');
        $serverUpdateTime = $this->fetchAreasUpdateTime();
        $localUpdateTime  = $this->cache->get($timeCacheKey);
        if ($serverUpdateTime && $serverUpdateTime === $localUpdateTime) {
            $compressedAreas = $this->cache->get($areasCacheKey);
            if ($compressedAreas) {
                $this->cache->put($checkedCacheKey, 1, 60 * 3);
                return $compressedAreas;
            }
        }

        // 从服务器获取
        $compressedAreas = $this->fetchCompressedAreas();
        $this->cache->forever($areasCacheKey, $compressedAreas);
        $this->cache->forever($timeCacheKey, $serverUpdateTime);
        $this->cache->put($checkedCacheKey, 1, 60 * 3);

        return $compressedAreas;
    }

    /**
     * 获取地址库最后更新时间
     *
     * @return string
     */
    protected function fetchAreasUpdateTime()
    {
        try {
            return $this->publicClient()->get('config')->getJson()['update_time'];
        } catch (\Throwable $e) {
            throw new InternalServerException('获取地址信息失败', $e);
        }
    }

    /**
     * 从服务器获取压缩过的区域列表
     *
     * @return array
     */
    protected function fetchCompressedAreas()
    {
        try {
            return $this->publicClient()->get('areas', [], [
                'query' => [
                    'level'        => 5,
                    'compress'     => 1,
                    'with_deleted' => 1,
                    'with_oversea' => 1,
                ],
            ])->getJson();
        } catch (\Throwable $e) {
            throw new InternalServerException('获取地址信息失败', $e);
        }
    }
}