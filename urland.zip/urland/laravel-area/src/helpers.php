<?php

if (!function_exists('area')) {

    /**
     * Get Area.
     *
     * @param null|string $code
     * @param bool        $throwException
     *
     * @return \Urland\Area\AreaManager|Urland\Area\Area
     */
    function area($code = null, $throwException = true)
    {
        $areaManager = app('area');
        if (func_num_args() === 0) {
            return $areaManager;
        }

        return $areaManager->getAreaByCode($code, $throwException);
    }
}