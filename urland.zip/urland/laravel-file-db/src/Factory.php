<?php

namespace Urland\FileDB;

use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Collection;

class Factory
{
    /**
     * The file finder implementation.
     *
     * @var \Urland\FileDB\FileFinder
     */
    protected $finder;

    /**
     * The filesystem instance.
     *
     * @var \Illuminate\Filesystem\Filesystem
     */
    protected $files;

    /**
     * File database collections.
     *
     * @var \Illuminate\Support\Collection[]
     */
    protected $collections = [];

    /**
     * Factory constructor.
     *
     * @param \Urland\FileDB\FileFinder         $finder
     * @param \Illuminate\Filesystem\Filesystem $files
     */
    public function __construct(FileFinder $finder, Filesystem $files)
    {
        $this->finder = $finder;
        $this->files  = $files;
    }

    /**
     * Get the file database for the given name.
     *
     * @param string $name
     *
     * @return \Illuminate\Support\Collection
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function load($name)
    {
        if (isset($this->collections[$name])) {
            return $this->collections[$name];
        }

        $path = $this->finder->find($name);
        return $this->collections[$name] = $this->resolve($path);
    }

    /**
     * Load collection from file.
     *
     * @param string $path
     *
     * @return \Illuminate\Support\Collection
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    protected function resolve($path)
    {
        $contents = $this->files->getRequire($path);

        @list('type' => $type, 'columns' => $columns, 'defaults' => $defaults, 'records' => $records) = $contents;

        if ($type === 'object') {
            $items = array_map(function ($record) use ($columns, $defaults) {
                return array_merge(array_combine($columns, $defaults), $record);
            }, (array)$records);
        } else {
            $items = array_map(function ($record) use ($columns) {
                return array_combine($columns, $record);
            }, (array)$records);
        }

        return new Collection($items);
    }
}