<?php

namespace Urland\FileDB;

use Illuminate\Filesystem\Filesystem;

class FileFinder
{
    /**
     * The filesystem instance.
     *
     * @var \Illuminate\Filesystem\Filesystem
     */
    protected $filesystem;

    /**
     * The path to find database files.
     *
     * @var array|string
     */
    protected $paths;

    /**
     * The array of files that have been located.
     *
     * @var array
     */
    protected $files = [];

    /**
     * FileFinder constructor.
     *
     * @param Filesystem $filesystem
     * @param array|string $paths
     */
    public function __construct(Filesystem $filesystem, $paths)
    {
        $this->filesystem = $filesystem;
        $this->paths      = $paths;
    }

    /**
     * Get the fully qualified location of the database file.
     *
     * @param  string $name
     *
     * @return string
     */
    public function find($name)
    {
        if (isset($this->files[$name])) {
            return $this->files[$name];
        }

        return $this->files[$name] = $this->findInPaths($name, $this->paths);
    }

    /**
     * Find the given name in the list of paths.
     *
     * @param  string $name
     * @param  array $paths
     *
     * @return string
     *
     */
    protected function findInPaths($name, $paths)
    {
        $file = str_replace('.', '/', $name);

        foreach ((array)$paths as $path) {
            if ($this->filesystem->exists($filePath = $path . '/' . $file . '.php')) {
                return $filePath;
            }
        }

        throw new \InvalidArgumentException("FileDB file [{$name}] not found.");
    }


}