<?php

if (!function_exists('file_db')) {

    /**
     * Get file-db object or load file-db file using name.
     *
     * @param null|string $name
     *
     * @return Urland\FileDB\Factory|Illuminate\Support\Collection
     */
    function file_db($name = null)
    {
        $fileDb = app('file-db');
        if (is_null($name)) {
            return $fileDb;
        }

        return $fileDb->load($name);
    }
}