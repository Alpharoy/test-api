<?php

namespace Urland\FileDB;

use Illuminate\Support\ServiceProvider;

class FileDBServiceProvider extends ServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = true;

    /**
     * Bootstrap the application file database.
     *
     * @return void
     */
    public function boot()
    {
        // 配置发布
        if ($this->app->runningInConsole()) {
            $this->publishes([
                __DIR__ . '/../file-databases/' => $this->app->resourcePath('file-databases'),
            ], 'urland-file-db');
        }
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton('file-db.finder', function ($app) {
            return new FileFinder($app['files'], $app->resourcePath('file-databases'));
        });

        $this->app->singleton('file-db', function ($app) {
            $finder = $app['file-db.finder'];
            $files  = $app['files'];

            $fileDb = new Factory($finder, $files);

            return $fileDb;
        });
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return ['file-db', 'file-db.finder'];
    }
}
