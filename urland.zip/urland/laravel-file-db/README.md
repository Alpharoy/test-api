# 悠然居文件数据库组件

储存不常变更的数据到文件里面，此库只负责读取与解析。

### 安装方法

1. 配置composer.json
```json
    {
        "repositories": [
            {
              "type": "composer",
              "url": "https://satis.muniu.urland.cn"
            }
        ]
    }
```

2. 命令行执行引入此库
```shell
    composer require urland/laravel-file-db
```

3. **\[可选\]** 如果需要示例，可执行此命令生成文件
```
    php artisan vendor:publish --tag=urland-file-db
```

4. 完成

### 使用说明

**数据库文件请存放于 `resources/file-databases` 目录下**

示例文件 resources/file-databases/example/sub-example.php
```php
    return [
        'columns' => ['username', 'nickname', 'age'],

        'comments' => ['用户名', '昵称', '年龄'],

        'records' => [
            ['tony', 'Tony Jam', 18],
            ['jim', 'Jimmy', 20],
            ['roger', 'Roger Chan', 24],
            ['kate', '凯蒂', 18],
        ],
    ];
```

1. 读取文件数据
```php
    // 通过Facades读取
    $subExamples = \FileDB::load('example.sub-example');

    // 通过helpers读取
    $subExamples = file_db('example.sub-example');
    $subExamples = file_db()->load('example.sub-example');
```

2. 字段过滤
```php
    // 只获取用户名与年龄
    $onlyUsernameAndAge = $subExamples->map(function($record) {
        return array_only($record, ['username', 'age']);
    });

    // 不获取用户名
    $exceptUsername = $subExamples->map(function($record) {
       return array_except($record, ['username']);
    });
```

3. 字段抽取
```php
    // 抽取用户名作为一个数组
    $usernames = $subExamples->pluck('username');
    // $usernames == ['tony','jim','roger','kate']

    // 用户名 => 年龄数组
    $usernameAges = $subExamples->pluck('age', 'username');
    // $usernameAges == ['tony'=>18,'jim'=>20,'roger'=>24,'kate'=>18]
```

4. 数据过滤
```php
    // 只获取年龄超过20岁的数据
    $filterByAge = $subExamples->where('age', '>=', 20);
    // $filterByAge 只有 jim 和 roger
```

更多用法请参考 [官方文档](https://laravel-china.org/docs/laravel/5.6/collections)