<?php

return [
    'columns' => ['type', 'name'],

    'comments' => ['类型', '名称'],

    'records' => [
        [1, '类型1'],
        [2, '类型2']
    ],
];