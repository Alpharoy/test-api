<?php

namespace Urland\ApiDocs;

use Illuminate\Support\ServiceProvider as BaseServiceProvider;

class ApiDocsServiceProvider extends BaseServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = true;

    /**
     * Bootstrap the application urland api client.
     *
     * @return void
     */
    public function boot()
    {
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton('api-docs', function ($app) {
            return new Factory($app);
        });

        $this->app->singleton('command.api-docs.generate', function () {
            return new Commands\GenerateDocs();
        });

        $this->commands([
            'command.api-docs.generate',
        ]);
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [
            'api-docs',
            'command.api-docs.generate',
        ];
    }

    /**
     * Get the config path
     *
     * @return string
     */
    protected function getConfigPath()
    {
        return config_path('api-docs.php');
    }
}