<?php

namespace Urland\ApiDocs\Annotations;

class Route
{

    /**
     * @var array
     */
    public $methods = [];

    /**
     * @var string
     */
    public $uri;

    /**
     * @var array
     */
    public $middlewares = [];

    /**
     * @var array
     */
    public $tags = [];

    /**
     * @var string
     */
    public $summary = '';

    /**
     * @var string
     */
    public $description = '';

    /**
     * 参数列表
     *
     * @var \Urland\ApiDocs\Annotations\RouteParameter[]
     */
    public $parameters = [];

    /**
     * @var \Urland\ApiDocs\Annotations\Response[]
     */
    public $responses = [];
}