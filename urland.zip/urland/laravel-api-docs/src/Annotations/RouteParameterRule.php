<?php

namespace Urland\ApiDocs\Annotations;

use Illuminate\Validation\ValidationRuleParser;

class RouteParameterRule
{
    const TYPE_INT = 'int32';
    const TYPE_BIGINT = 'int64';
    const TYPE_FLOAT = 'float';
    const TYPE_DOUBLE = 'double';
    const TYPE_STRING = 'string';
    const TYPE_BYTE = 'byte';
    const TYPE_BINARY = 'binary';
    const TYPE_BOOL = 'boolean';
    const TYPE_DATE = 'date';
    const TYPE_DATETIME = 'datetime';
    const TYPE_PASSWORD = 'password';
    const TYPE_ARRAY = 'array';

    const PRIMITIVE_TYPE_INTEGER = 'integer';
    const PRIMITIVE_TYPE_NUMBER = 'number';
    const PRIMITIVE_TYPE_STRING = 'string';
    const PRIMITIVE_TYPE_BOOLEAN = 'boolean';
    const PRIMITIVE_TYPE_ARRAY = 'array';

    /**
     * 数据类型
     *
     * @var string
     */
    public $type;

    /**
     * 原始数据类型
     *
     * @var string
     */
    public $primitiveType;

    /**
     * 是否必传参数
     *
     * @var bool
     */
    public $required = false;

    /**
     * 参数是否允许null
     *
     * @var bool
     */
    public $nullable = false;

    /**
     * 示例值
     *
     * @var mixed
     */
    public $example;

    /**
     * 最大值
     *
     * @var int
     */
    public $max;

    /**
     * 最小值
     *
     * @var int
     */
    public $min;

    /**
     * 规则描述
     *
     * @var array
     */
    public $descriptions = [];

    /**
     * 原始类型对应
     *
     * @var array
     */
    protected $primitiveTypeMap = [
        self::TYPE_INT      => self::PRIMITIVE_TYPE_INTEGER,
        self::TYPE_BIGINT   => self::PRIMITIVE_TYPE_INTEGER,
        self::TYPE_FLOAT    => self::PRIMITIVE_TYPE_NUMBER,
        self::TYPE_DOUBLE   => self::PRIMITIVE_TYPE_NUMBER,
        self::TYPE_STRING   => self::PRIMITIVE_TYPE_STRING,
        self::TYPE_BYTE     => self::PRIMITIVE_TYPE_STRING,
        self::TYPE_BINARY   => self::PRIMITIVE_TYPE_STRING,
        self::TYPE_BOOL     => self::PRIMITIVE_TYPE_BOOLEAN,
        self::TYPE_DATE     => self::PRIMITIVE_TYPE_STRING,
        self::TYPE_DATETIME => self::PRIMITIVE_TYPE_STRING,
        self::TYPE_PASSWORD => self::PRIMITIVE_TYPE_STRING,
        self::TYPE_ARRAY    => self::PRIMITIVE_TYPE_ARRAY,
    ];

    /**
     * RouteParameterRule constructor.
     *
     * @param array $rules
     */
    public function __construct(array $rules)
    {
        foreach ($rules as $rule) {
            $this->parseRule($rule);
        }
    }

    /**
     * 将规则转换成成员变量
     *
     * @param string $rule
     */
    protected function parseRule($rule)
    {
        // TODO: 完成规则库
        list($rule, $parameters) = ValidationRuleParser::parse($rule);
        switch ($rule) {
            case 'Accepted':
                $this->required = true;
                $this->type     = self::TYPE_BOOL;
                $this->example  = true;
                break;
            case 'ActiveUrl':
                break;
            case 'After':
                $this->type = self::TYPE_DATE;
                break;
            case 'AfterOrEqual':
                $this->type = self::TYPE_DATE;
                break;
            case 'Alpha':
                $this->type = self::TYPE_STRING;
                break;
            case 'AlphaDash':
                $this->type = self::TYPE_STRING;
                break;
            case 'AlphaNume':
                $this->type = self::TYPE_STRING;
                break;
            case 'Array':
                $this->type = self::TYPE_ARRAY;
                break;
            case 'Bail':
                break;
            case 'Before':
                $this->type = self::TYPE_DATE;
                break;
            case 'BeforeOrEqual':
                $this->type = self::TYPE_DATE;
                break;
            case 'Between':
                break;
            case 'Boolean':
                $this->type = self::TYPE_BOOL;
                break;
            case 'Confirmed':
                $this->type = self::TYPE_STRING;
                break;
            case 'Date':
                $this->type = self::TYPE_DATE;
                break;
            case 'DateEquals':
                $this->type = self::TYPE_DATE;
                break;
            case 'DateFormat':
                break;
            case 'Different':
                break;
            case 'Digits':
                $this->type = self::TYPE_INT;
                break;
            case 'DigitsBetween':
                $this->type = self::TYPE_INT;
                break;
            case 'Dimensions':
                break;
            case 'Distinct':
                break;
            case 'Email':
                break;
            case 'Exists':
                break;
            case 'File':
                break;
            case 'Filled':
                break;
            case 'Image':
                break;
            case 'In':
                break;
            case 'InArray':
                break;
            case 'Integer':
                $this->type = self::TYPE_INT;
                break;
            case 'Ip':
                $this->type = self::TYPE_STRING;
                break;
            case 'Ipv4':
                $this->type = self::TYPE_STRING;
                break;
            case 'Ipv6':
                $this->type = self::TYPE_STRING;
                break;
            case 'Json':
                $this->type = self::TYPE_STRING;
                break;
            case 'Max':
                $this->max = (int)$parameters[0];
                break;
            case 'Mimetypes':
                break;
            case 'Mimes':
                break;
            case 'Min':
                $this->min = (int)$parameters[0];
                break;
            case 'NotIn':
                break;
            case 'NotRegex':
                break;
            case 'Nullable':
                $this->nullable = true;
                break;
            case 'Numeric':
                $this->type = self::TYPE_DOUBLE;
                break;
            case 'Present':
                break;
            case 'Regex':
                break;
            case 'Required':
                $this->required = true;
                break;
            case 'RequiredIf':
                break;
            case 'RequiredUnless':
                break;
            case 'RequiredWith':
                break;
            case 'RequiredWithAll':
                break;
            case 'RequiredWithout':
                break;
            case 'RequiredWithoutAll':
                break;
            case 'Same':
                break;
            case 'Size':
                $this->min = $this->max = (int)$parameters[0];
                break;
            case 'String':
                $this->type = self::TYPE_STRING;
                break;
            case 'Timezone':
                break;
            case 'Unique':
                break;
            case 'Url':
                $this->type = self::TYPE_STRING;
                break;
        }

        if ($this->type) {
            $this->primitiveType = $this->primitiveTypeMap[$this->type];
        }
    }

    protected function isNumericType()
    {

    }
}