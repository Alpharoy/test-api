<?php

namespace Urland\ApiDocs\Annotations;

class Response
{
    const MEDIA_TYPE_JSON = 'application/json';

    /**
     * 对应响应的名称
     *
     * @var string
     */
    public $className;

    /**
     * 状态码
     *
     * @var int
     */
    public $statusCode;

    /**
     * 描述
     *
     * @var string
     */
    public $description = '';

    /**
     * 附带头部
     *
     * @var array
     */
    public $headers = [];

    /**
     * 响应类型
     *
     * @var string
     */
    public $mediaType;

    /**
     * 是否数组
     *
     * @var bool
     */
    public $isCollection = false;

    /**
     * 响应属性
     *
     * @var array
     */
    public $properties = [];

    /**
     * 创建JSON响应
     *
     * @return \Urland\ApiDocs\Annotations\Response
     */
    static function createJson()
    {
        $response = new static();

        $response->mediaType = static::MEDIA_TYPE_JSON;

        return $response;
    }
}