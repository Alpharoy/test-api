<?php

namespace Urland\ApiDocs\Analysers;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Routing\Route;
use Illuminate\Support\Arr;
use phpDocumentor\Reflection\DocBlockFactory;
use Urland\ApiDocs\Annotations\Response as AnnotationResponse;
use Urland\ApiDocs\Annotations\Route as AnnotationRoute;
use Urland\ApiDocs\Annotations\RouteParameter as AnnotationRouteParameter;
use Urland\ApiDocs\Annotations\RouteParameterRule as AnnotationRouteParameterRule;

abstract class Analyser
{

    /**
     * Laravel Application
     *
     * @var \Illuminate\Contracts\Foundation\Application
     */
    protected $app;

    /**
     * DocBlockFactory
     *
     * @var \phpDocumentor\Reflection\DocBlockFactory
     */
    protected $docBlockFactory;

    /**
     * @var string
     */
    protected $uriPrefix;

    /**
     *
     * Analyser constructor.
     *
     * @param \Illuminate\Contracts\Foundation\Application $app
     * @param array                                        $options
     *
     * @throws \InvalidArgumentException
     */
    public function __construct(Application $app, array $options)
    {
        $this->app             = $app;
        $this->docBlockFactory = DocBlockFactory::createInstance();
        $this->uriPrefix       = trim(Arr::get($options, 'uri'), '/');

        if (empty($this->uriPrefix)) {
            throw new \InvalidArgumentException('Config should set uri.');
        }
    }

    /**
     * 将当前路由列表转化成可读对象
     *
     * @return array
     * @throws \InvalidArgumentException
     * @throws \ReflectionException
     */
    public function getAnnotationRoutes()
    {
        $annotationRoutes = [];

        $routes = $this->app->make('router')->getRoutes();
        foreach ($routes as $route) {
            // 只解析匹配url的路由
            /* @var \Illuminate\Routing\Route $route */
            if (!starts_with($route->uri(), $this->uriPrefix)) {
                continue;
            }

            // 跳过空调用和可执行函数
            $routeHandler = $route->getAction()['uses'];
            if (empty($routeHandler) || is_callable($routeHandler)) {
                continue;
            }

            $annotationRoutes[] = $this->transformRouteToAnnotation($route);
        }

        return $annotationRoutes;
    }

    /**
     * 将路由转化成已解析的对象
     *
     * @param \Illuminate\Routing\Route $route
     *
     * @return \Urland\ApiDocs\Annotations\Route
     */
    /**
     * @param \Illuminate\Routing\Route $route
     *
     * @return \Urland\ApiDocs\Annotations\Route
     * @throws \InvalidArgumentException
     * @throws \ReflectionException
     */
    protected function transformRouteToAnnotation(Route $route)
    {
        $annotationRoute = new AnnotationRoute();
        // 添加请求方法与url
        $annotationRoute->methods     = $route->methods();
        $annotationRoute->uri         = substr($route->uri(), strlen($this->uriPrefix));
        $annotationRoute->middlewares = $route->gatherMiddleware();

        // 反射执行方法
        $routeAction = $route->getAction();
        list($controllerClass, $method) = explode('@', $routeAction['uses']);
        $reflectionClass  = new \ReflectionClass($controllerClass);
        $reflectionMethod = $reflectionClass->getMethod($method);

        $docBlock = $this->docBlockFactory->create($reflectionMethod->getDocComment());
        // 添加概要与详情
        $annotationRoute->summary     = $docBlock->getSummary();
        $annotationRoute->description = $docBlock->getDescription();

        // 添加标签
        $annotationRoute->tags = $this->analyseRouteTags($reflectionClass);

        // 添加请求参数
        $annotationRoute->parameters = $this->analyseRouteParameters($reflectionMethod, $route);

        // 添加响应参数
        $annotationRoute->responses = $this->analysisRouteResponses($reflectionMethod);

        return $annotationRoute;
    }

    /**
     * 分析标签
     *
     * @param \ReflectionClass $reflectionClass
     *
     * @return array
     */
    protected function analyseRouteTags(\ReflectionClass $reflectionClass)
    {
        $tags             = [];
        $parentNamespace  = $reflectionClass->getParentClass()->getNamespaceName();
        $currentNamespace = $reflectionClass->getNamespaceName();
        if (strpos($currentNamespace, $parentNamespace) === 0) {
            $difference = substr($currentNamespace, strlen($parentNamespace) + 1);
            $tags[]     = kebab_case(str_replace('\\', '', $difference));
        }

        return $tags;
    }

    /**
     * 分析路由参数
     *
     * @param \ReflectionMethod         $reflectionMethod
     * @param \Illuminate\Routing\Route $route
     *
     * @return \Urland\ApiDocs\Annotations\RouteParameter[]
     */
    protected function analyseRouteParameters(\ReflectionMethod $reflectionMethod, Route $route)
    {
        $rules      = [];
        $attributes = [];

        foreach ($reflectionMethod->getParameters() as $parameter) {
            $parameterType = $parameter->getClass();
            if ($parameterType && class_exists($parameterType->name) &&
                is_subclass_of($parameterType->name, FormRequest::class)) {
                /* @var FormRequest $request */
                $request = new $parameterType->name;
                $request->setContainer($this->app);
                // TODO: Add route parameter bindings
//                $parameterReflection->query->add($bindings);
//                $parameterReflection->request->add($bindings);

                if (method_exists($request, 'validator')) {
                    $validator  = $this->app->call([$request, 'validator']);
                    $rules      = $validator->getRules();
                    $attributes = $validator->getAttributes();
                } else if (method_exists($request, 'rules') &&
                    method_exists($request, 'attributes')) {
                    $rules      = $this->app->call([$request, 'rules']);
                    $attributes = $this->app->call([$request, 'attributes']);
                }
                break;
            }
        }

        $parameters = [];
        // URL参数
        if ($compiledRoute = $route->getCompiled()) {
            $docBlock = $this->docBlockFactory->create($reflectionMethod->getDocComment());
            // 解析路由文本
            $descriptions = [];
            foreach ($docBlock->getTagsByName('param') as $param) {
                /* @var \phpDocumentor\Reflection\DocBlock\Tags\Param $param */
                $descriptions[$param->getVariableName()] = (string)$param->getDescription();
            }

            foreach ($compiledRoute->getPathVariables() as $variable) {
                $routeParameter = new AnnotationRouteParameter();

                $routeParameter->name        = $variable;
                $routeParameter->in          = AnnotationRouteParameter::IN_PATH;
                $routeParameter->rule        = new AnnotationRouteParameterRule(['string']);
                $routeParameter->description = Arr::get($descriptions, $variable, $variable);

                $parameters[] = $routeParameter;
            }
        }

        // Request参数
        $validator = $this->app->make('validator')->make([], $rules);
        foreach ($validator->getRules() as $name => $rules) {
            $routeParameter = new AnnotationRouteParameter();

            $routeParameter->name        = $name;
            $routeParameter->in          = AnnotationRouteParameter::IN_QUERY;
            $routeParameter->rule        = new AnnotationRouteParameterRule($rules);
            $routeParameter->description = Arr::get($attributes, $name, '');

            $parameters[] = $routeParameter;
        }

        return $parameters;
    }

    /**
     * 分析路由响应
     *
     * @param \ReflectionMethod $reflectionMethod
     *
     * @return \Urland\ApiDocs\Annotations\Response[]
     * @throws \InvalidArgumentException
     */
    protected function analysisRouteResponses(\ReflectionMethod $reflectionMethod)
    {
        $responses = [];
        $docBlock  = $this->docBlockFactory->create($reflectionMethod->getDocComment());
        // 获取@return注释
        $returnTag = head($docBlock->getTagsByName('return'));
        if ($returnTag instanceof \phpDocumentor\Reflection\DocBlock\Tags\Return_) {
            $isCollection  = false;
            $returnTagType = $returnTag->getType();
            if ($returnTagType instanceof \phpDocumentor\Reflection\Types\Array_) {
                $isCollection  = true;
                $returnTagType = $returnTagType->getValueType();
            }

            $className = (string)$returnTagType->getFqsen();
            if (class_exists($className) && method_exists($className, 'schema')) {
                $schema     = $className::schema();
                $properties = $className::properties();

                $response    = AnnotationResponse::createJson();
                $responses[] = $response;

                $response->isCollection = $isCollection;
                $response->className    = $className;
                $response->statusCode   = Arr::get($schema, 'statusCode', 200);
                $response->description  = Arr::get($schema, 'description');
                $response->properties   = $properties;
            }
        }

        return $responses;
    }
}