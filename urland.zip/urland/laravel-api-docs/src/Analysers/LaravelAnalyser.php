<?php

namespace Urland\ApiDocs\Analysers;

class LaravelAnalyser extends Analyser
{
}
