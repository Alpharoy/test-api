<?php

namespace Urland\ApiDocs;

use Illuminate\Support\Arr;
use Urland\ApiDocs\Analysers\LaravelAnalyser;
use Urland\ApiDocs\Generators\OpenApiGenerator;

class Factory
{
    /**
     * @var \Illuminate\Contracts\Foundation\Application
     */
    protected $app;

    /**
     * @var string
     */
    protected $buildPath;

    /**
     * @var array
     */
    protected $providers;

    /**
     * @var array
     */
    protected $generators = [];

    /**
     * Factory constructor.
     *
     * @param \Illuminate\Contracts\Foundation\Application $app
     */
    public function __construct($app)
    {
        $this->app = $app;

        $config          = $this->app->make('config')->get('api-docs', []);
        $this->buildPath = Arr::get($config, 'build_path');
        $this->providers = Arr::get($config, 'providers', []);
    }

    /**
     * 根据名称生成文档
     *
     * @param string $name
     *
     * @return mixed
     * @throws \InvalidArgumentException
     */
    public function generate($name)
    {
        return $this->resolve($name)->generate();
    }

    /**
     * 将文档写入路径
     *
     * @param string $name
     *
     * @return bool
     * @throws \InvalidArgumentException
     */
    public function build($name)
    {
        return $this->resolve($name)->build($name, $this->buildPath);
    }

    /**
     * 解析generator
     *
     * @param string $name
     *
     * @return \Urland\ApiDocs\Generators\Generator
     * @throws \InvalidArgumentException
     */
    protected function resolve($name)
    {
        if (!isset($this->providers[$name])) {
            throw new \InvalidArgumentException('Provider name [' . $name . '] does not exists.');
        }

        if (isset($this->generators[$name])) {
            return $this->generators[$name];
        }

        $provider = $this->providers[$name];
        $options  = Arr::pull($provider, 'options', []);

        $analyser  = new LaravelAnalyser($this->app, ['uri' => Arr::get($provider, 'uri')]);
        $generator = new OpenApiGenerator($this->app, $analyser, $options);

        return $this->generators[$name] = $generator;
    }

}