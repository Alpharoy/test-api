<?php

namespace Urland\ApiDocs\Generators;

use ReflectionClass;
use Illuminate\Console\Command;
use\Illuminate\Contracts\Foundation\Application;
use Illuminate\Support\Arr;
use Urland\ApiDocs\Analysers\Analyser;

abstract class Generator
{
    /**
     * @var \Illuminate\Contracts\Foundation\Application
     */
    protected $app;

    /**
     * @var \Urland\ApiDocs\Analysers\Analyser
     */
    protected $analyser;

    /**
     * @var \Illuminate\Console\Command;
     */
    protected $command;

    /**
     * @var array
     */
    protected $options;

    /**
     * Generator constructor.
     *
     * @param \Illuminate\Contracts\Foundation\Application $app
     * @param \Urland\ApiDocs\Analysers\Analyser           $analyser
     * @param array                                        $options
     */
    public function __construct(Application $app, Analyser $analyser, array $options)
    {
        $this->app      = $app;
        $this->analyser = $analyser;
        $this->options  = $options;
    }

    /**
     * 生成文档
     *
     * @return mixed
     */
    abstract public function generate();

    /**
     * 生成文件
     *
     * @param string $name
     * @param string $path
     *
     * @return bool
     */
    abstract public function build($name, $path);

    /**
     * 获取配置信息
     *
     * @param string $key
     * @param mixed  $default
     *
     * @return mixed
     */
    protected function option($key, $default = null)
    {
        return Arr::get($this->options, $key, $default);
    }
}