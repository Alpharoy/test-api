<?php

namespace Urland\ApiDocs\Generators;

use Illuminate\Support\Arr;
use OpenApi\Analysis;
use OpenApi\Annotations\ExternalDocumentation;
use OpenApi\Annotations\Info;
use OpenApi\Annotations\Items;
use OpenApi\Annotations\MediaType;
use OpenApi\Annotations\Parameter;
use OpenApi\Annotations\Property;
use OpenApi\Annotations\Response;
use OpenApi\Annotations\Schema;
use OpenApi\Annotations\SecurityScheme;
use OpenApi\Context;

/**
 * Class OpenApiGenerator
 *
 * @package Urland\ApiDocs\Generators
 */
class OpenApiGenerator extends Generator
{
    /**
     * 资源定义数组
     *
     * @var \OpenApi\Annotations\Schema
     */
    protected $oaSchemas = [];

    /**
     * 生成文件
     *
     * @return string
     * @throws \InvalidArgumentException
     * @throws \ReflectionException
     * @throws \RuntimeException
     */
    public function generate()
    {
        $openApiAnalysis = $this->createOpenApiAnalysisFromAnalyser();

        // Post processing
        $openApiAnalysis->process(Analysis::processors());
        // Validation (Generate notices & warnings)
        $openApiAnalysis->validate();

        return $openApiAnalysis->openapi->toJson();
    }

    /**
     * 生成文档文件
     *
     * @param string $name
     * @param string $path
     *
     * @return bool
     * @throws \InvalidArgumentException
     * @throws \ReflectionException
     * @throws \RuntimeException
     */
    public function build($name, $path)
    {
        // 生成目录
        \File::makeDirectory($path, 777, true, true);
        // 生成文件
        $result = file_put_contents($path . DIRECTORY_SEPARATOR . $name . '.json', $this->generate());

        return $result !== false;
    }

    /**
     * 创建OpenApiAnalysis
     *
     * @return \OpenApi\Analysis
     * @throws \InvalidArgumentException
     * @throws \ReflectionException
     * @throws \RuntimeException
     */
    protected function createOpenApiAnalysisFromAnalyser()
    {
        $analysis = new \OpenApi\Analysis();

        // 添加项目信息
        $analysis->annotations->attach(new Info($this->option('info')), Context::detect(1));
        // 添加扩展文档信息
        if ($externalDocs = $this->option('external_docs')) {
            $analysis->annotations->attach(new ExternalDocumentation($externalDocs), Context::detect(1));
        }

        $annotationRoutes   = $this->analyser->getAnnotationRoutes();
        $openApiAnnotations = $this->transformToOpenApiAnnotations($annotationRoutes);
        foreach ($openApiAnnotations as $annotation) {
            $analysis->annotations->attach($annotation, Context::detect(1));
        }

        // 添加全局schema
        foreach ($this->oaSchemas as $schema) {
            $analysis->annotations->attach($schema, Context::detect(1));
        }

        return $analysis;
    }

    /**
     * 将注释转化成OpenApi的注释
     *
     * @param \Urland\ApiDocs\Annotations\Route[] $annotationRoutes
     *
     * @return \OpenApi\Annotations\AbstractAnnotation[]
     * @throws \RuntimeException
     */
    protected function transformToOpenApiAnnotations($annotationRoutes)
    {
        $annotations = [];
        foreach ($annotationRoutes as $annotationRoute) {
            foreach ($annotationRoute->methods as $method) {
                $method = strtolower($method);
                // 跳过head方法
                if (in_array($method, ['head'])) {
                    continue;
                }

                $className = 'OpenApi\Annotations\\' . ucfirst($method);
                if (!class_exists($className)) {
                    // TODO: 打印错误
                    continue;
                }

                $security = null;
                foreach ($annotationRoute->middlewares as $middleware) {
                    if (strpos($middleware, 'auth') === 0) {
                        $security = new SecurityScheme([
                            'securityScheme' => 'http',
                            'type'           => 'apiKey',
                            'description'    => '授权',
                            'name'           => 'X-Api-Token',
                            'in'             => 'header',
                        ]);
                        break;
                    }
                }

                $values = collect($this->transformToOpenApiParameters($annotationRoute->parameters));
                $values = $values->concat($this->transformToOpenApiResponses($annotationRoute->responses));
                if ($security) {
                    $values->push($security);
                }

                $uriPaths      = preg_split("/[\/\-\_\{\}]+/", $annotationRoute->uri);
                $annotations[] = new $className([
                    'tags'        => $annotationRoute->tags,
                    'path'        => $annotationRoute->uri,
                    'operationId' => $method . implode('', $uriPaths),
                    'summary'     => $annotationRoute->summary,
                    'description' => (string)$annotationRoute->description,
                    'security'    => $security,
                    'value'       => $values->toArray(),
                ]);
            }
        }

        return $annotations;
    }

    /**
     * 将参数转换成OpenApi注释
     *
     * @param \Urland\ApiDocs\Annotations\RouteParameter[] $annotationParameters
     *
     * @return \OpenApi\Annotations\Parameter[]
     */
    protected function transformToOpenApiParameters($annotationParameters)
    {
        $parameters = [];
        foreach ($annotationParameters as $annotationParameter) {
            $rule = $annotationParameter->rule;

            // 设置最大最小值
            $maximum = $minimum = $maxLength = $minLength = null;
            if ($rule->primitiveType === $rule::PRIMITIVE_TYPE_INTEGER) {
                $maximum = $rule->max;
                $minimum = $rule->min;
            } else {
                $maxLength = $rule->max;
                $minLength = $rule->min;
            }

            $schema = new Schema([
                'type'      => $rule->primitiveType,
                'format'    => $rule->type,
                'nullable'  => $rule->nullable,
                'maximum'   => $maximum,
                'minimum'   => $minimum,
                'maxLength' => $maxLength,
                'minLength' => $minLength,
                'value'     => new Items([
                    'type' => $rule->primitiveType === 'array' ? 'string' : $rule->primitiveType,
                ]),
            ]);

            $parameters[] = new Parameter([
                'name'        => $annotationParameter->name,
                'in'          => $annotationParameter->in,
                'required'    => $rule->required,
                'description' => $annotationParameter->description,
                'value'       => $schema,
            ]);
        }

        return $parameters;
    }

    /**
     * 将响应转换成OpenApi注释
     *
     * @param \Urland\ApiDocs\Annotations\Response[] $annotationResponses
     *
     * @return \OpenApi\Annotations\Response[]
     */
    protected function transformToOpenApiResponses($annotationResponses)
    {
        $responses = [];

        foreach ($annotationResponses as $annotationResponse) {
            $oaSchema = $this->loadResponseClassAsSchema($annotationResponse->className);

            $oaResponseSchema    = null;
            $additionDescription = '';
            if ($annotationResponse->isCollection) {
                $additionDescription = '数组';
                $oaResponseSchema    = new Schema([
                    'type'  => 'array',
                    'value' => new Items([
                        'ref' => '#/components/schemas/' . $oaSchema->schema,
                    ]),
                ]);
            } else {
                $oaResponseSchema = new Schema([
                    'ref' => '#/components/schemas/' . $oaSchema->schema,
                ]);
            }

            $responses[] = new Response([
                'response'    => $annotationResponse->statusCode,
                'description' => $annotationResponse->description . $additionDescription,
                'value'       => new MediaType([
                    'mediaType' => $annotationResponse->mediaType,
                    'value'     => $oaResponseSchema,
                ]),
            ]);
        }

        return $responses;
    }

    /**
     * 将响应对应的类转换成Schema
     *
     * @param string $className
     *
     * @return \OpenApi\Annotations\Schema|null
     */
    protected function loadResponseClassAsSchema($className)
    {
        if (!class_exists($className)) {
            return null;
        }


        $schemaName   = trim($className, '\\');
        $removePrefix = trim($this->option('schema.remove_prefix'), '\\');
        $removeSuffix = trim($this->option('schema.remove_suffix'), '\\');
        if ($removePrefix && strpos($schemaName, $removePrefix) === 0) {
            $schemaName = substr($schemaName, strlen($removePrefix));
        }

        if ($removeSuffix) {
            $shouldBePosition = strlen($schemaName) - strlen($removeSuffix);
            if (stripos($schemaName, $removeSuffix) === $shouldBePosition) {
                $schemaName = substr($schemaName, 0, $shouldBePosition);
            }
        }

        $schemaName = str_replace('\\', '', $schemaName);
        if (isset($this->oaSchemas[$schemaName])) {
            return $this->oaSchemas[$schemaName];
        }

        // 读取properties
        $oaProperties = [];
        $properties   = $className::properties();
        foreach ($properties as $name => $property) {
            $type = Arr::get($property, 'type', 'string');
            if ($type === 'object' || $type === 'collection') {
                // 加载子Model
                $oaSchema = $this->loadResponseClassAsSchema($property['ref']);
                if ($type === 'collection') {
                    $oaProperties[] = new Property([
                        'property' => $name,
                        'type'     => 'array',
                        'value'    => new Items([
                            'ref' => '#/components/schemas/' . $oaSchema->schema,
                        ]),
                    ]);
                } else {
                    $oaProperties[] = new Property([
                        'property' => $name,
                        'ref'      => '#/components/schemas/' . $oaSchema->schema,
                    ]);
                }
            } else {
                // 移除对解析文档无帮助的key
                unset($property['key'], $property['mutator']);
                // 添加当前属性名称
                $property['property'] = $name;
                // 数组额外处理格式
                if ($property['type'] === 'array') {
                    $property['value'] = new Items([
                        'type' => Arr::pull($property, 'format', 'string'),
                    ]);
                }

                $oaProperties[] = new Property($property);
            }
        }

        $oaSchema = new Schema([
            'schema' => $schemaName,
            'type'   => 'object',
            'value'  => $oaProperties,
        ]);

        return $this->oaSchemas[$schemaName] = $oaSchema;
    }
}