<?php

namespace Urland\ApiDocs\Commands;

use Illuminate\Support\Arr;
use ReflectionClass;
use Illuminate\Console\Command;
use phpDocumentor\Reflection\DocBlock;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Mpociot\Documentarian\Documentarian;
use Urland\ApiDocs\Analysers\Analyser;
use Urland\ApiDocs\Analysers\LaravelAnalyser;
use Urland\ApiDocs\Generators\OpenApiGenerator;

class GenerateDocs extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'api-docs:generate
                                    {name : The provider name for the generated documentation}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate your API documentation from existing Laravel routes.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return false|null
     */
    public function handle()
    {
        $providerName = $this->option('name');

        $this->laravel->make('api-docs');
        app('api-docs')->build();

        $config = $this->laravel->make('config')->get('api-docs');

        foreach (Arr::get($config, 'providers', []) as $name => $provider) {

            $options = Arr::pull($provider, 'options', []);

            $analyser  = new LaravelAnalyser($this->laravel, ['uri' => Arr::get($provider, 'uri')]);
            $generator = new OpenApiGenerator($this->laravel, $analyser, $options);

            $generator->generate();
        }
    }


    /**
     * Generate Postman collection JSON file.
     *
     * @param Collection $routes
     *
     * @return string
     */
    private function generatePostmanCollection(Collection $routes)
    {
        $writer = new CollectionWriter($routes);

        return $writer->getCollection();
    }
}