# 悠然居laravel项目restful接口请求库

用于restful层提供接口请求。

### 安装方法

1. 配置composer.json
```
    {
      "repositories": {
        "urland/laravel-api-client": {
          "type": "vcs",
          "url": "git@gitlab.come56.com:php-packages/laravel-api-client.git"
        }
      }
    }
```

2. 命令行执行引入此库
```shell
    composer require urland/laravel-api-client
```

3. 生成配置文件
```
    php artisan vendor:publish --provider="Urland\ApiClient\ServiceProvider"
```

4. 完成

### 使用说明

#### 支持的options

options覆盖优先级：请求附带options > `config['services'][name]` > `config['options']`

1. ApiClient 选项

    | 选项               | 说明                                       | 默认值         |
    | ------------------ | ----------------------------------------- | ------------- |
    | api_key            | 业务系统身份标识                            | ''            |
    | api_secret         | 业务系统秘钥                                | ''            |
    | api_sign           | 请求是否需要计算签名                         | false         |
    | api_sign_algorithm | 签名所用算法，支持"hmac-md5", "hmac-sha256" | 'hmac-sha256' |
    
2. GuzzleClient 选项

    参考 [GuzzleClient Options](http://docs.guzzlephp.org/en/stable/request-options.html)

#### 请求

支持调用的方法有：get, head, post, put, patch, delete

```php
    $data = [
        'id' => 1,
        'page' => 5,
    ];
    
    $client = \ApiClient::service('example');
    $response = $client->get($uri, $data, $options);
```

#### 响应

1. 数据获取
```php
    try {
        $response = $client->get('/'); // <---- 成功响应
    } catch (\GuzzleHttp\Exception\RequestException $exception) {
        $response = $exception->getResponse(); // <---- 异常响应
    }
    
    $jsonData = $response->getJson(); // 如果服务器返回非json，调用此方法会抛出异常
```

2. 分页
```php
    $paginate = $response->getPaginate();
    $paginate->getTotal(); // 总条数
    $paginate->getPerPage(); // 分页条数
    $paginate->getTotalPage(); // 总页数
    $paginate->getCurrentPage(); // 当前页数
    $paginate->getPrevPage(); // 上一页
    $paginate->getNextPage(); // 下一页
```

3. 限流
```php
    $rateLimit = $response->getRateLimit();
    $rateLimit->getLimit(); // 1分钟最多请求x次
    $rateLimit->getRemaining(); // 当前分钟剩余次数
    $rateLimit->getRetryAfter(); // 限制重置剩余秒数
    $rateLimit->getResetAt(); // 下次重置时间，\DateTime
```