<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Options
    |--------------------------------------------------------------------------
    |
    | Api client global options.
    |
    */
    'options' => [
        // 是否开启调试模式
        'debug' => false,

        // 所有服务是否需要签名
        'api_sign' => true,

        // 签名所用算法
        'api_sign_algorithm' => 'hmac-sha256',

        // 超时时间
        'timeout' => 10.0,
    ],

    /*
    |--------------------------------------------------------------------------
    | Default Options
    |--------------------------------------------------------------------------
    |
    | Api client services options.
    |
    */
    'services' => [
        'example' => [
            // api key
            'api_key' => 'random_key',
            // api secret
            'api_secret' => 'random_secret',
            // Base URI is used with relative requests
            'base_uri' => 'http://example.com/',
        ],
    ],
];