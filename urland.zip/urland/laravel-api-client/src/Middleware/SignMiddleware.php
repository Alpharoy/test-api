<?php

namespace Urland\ApiClient\Middleware;

use Psr\Http\Message\RequestInterface;

class SignMiddleware
{
    /**
     * SignMiddleware constructor.
     */
    public function __construct()
    {
    }

    /**
     * 签名调用方法
     *
     * @param callable $handler
     *
     * @return \Closure
     */
    public function __invoke(callable $handler)
    {
        return function (RequestInterface $request, array $options) use ($handler) {
            $needSign = isset($options['api_sign']) ? $options['api_sign'] : false;
            if ($needSign) {
                $apiKey        = isset($options['api_key']) ? $options['api_key'] : '';
                $apiSecret     = isset($options['api_secret']) ? $options['api_secret'] : '';
                $signAlgorithm = isset($options['api_sign_algorithm']) ? $options['api_sign_algorithm'] : 'hmac-sha256';

                $request = $this->prepareRequestSigning($request, $apiKey, $apiSecret, $signAlgorithm);
            }

            return $handler($request, $options);
        };
    }

    /**
     * Request准备
     *
     * @param RequestInterface $request
     * @param string           $apiKey
     * @param string           $apiSecret
     * @param string           $signAlgorithm
     *
     * @return RequestInterface
     * @throws \InvalidArgumentException
     * @throws \RuntimeException
     */
    private function prepareRequestSigning(RequestInterface $request, $apiKey, $apiSecret, $signAlgorithm)
    {
        $request = $request->withHeader('X-Api-Time', (new \DateTime())->format(DATE_RFC3339))
            ->withHeader('X-Api-Key', $apiKey)
            ->withHeader('X-Api-SignatureAlgorithm', $signAlgorithm);

        // 1. 请求方法
        $overrideMethod = $request->getHeader('X-HTTP-Method-Override');
        $method         = ($overrideMethod ?: $request->getMethod());

        // 2. 请求路径
        $path = $request->getUri()->getPath();

        // 3. 查询字符串
        parse_str($request->getUri()->getQuery(), $queries);
        ksort($queries, SORT_STRING);
        $queriesString = http_build_query($queries, null, '&', PHP_QUERY_RFC3986);

        // 4. 头部
        $headers = [];
        foreach ($request->getHeaders() as $key => $values) {
            $headers[strtolower($key)] = reset($values);
        }

        ksort($headers, SORT_STRING);
        $signedHeadersString = implode(';', array_keys($headers));
        $headersString       = array_reduce(array_keys($headers), function ($carry, $key) use ($headers) {
            return $carry . $key . ':' . $headers[$key] . "\n";
        });

        // 5. body签名
        $bodySignature = $this->sign($signAlgorithm, $request->getBody()->getContents(), $apiSecret);

        // 6. 组合成待签名字符串
        $signValues = [
            $method, // verb
            $path, // path
            $queriesString, // all queries as string
            $headersString, // all headers as string
            $signedHeadersString, // signed headers as string
            $bodySignature, // request content hashed
        ];
        $signString = implode("\n", $signValues);

        // 7. 组合字符串签名
        $signature = $this->sign($signAlgorithm, $signString, $apiSecret);

        // 8. 附带在header上
        return $request->withHeader('X-Api-SignedHeaders', $signedHeadersString)
            ->withHeader('X-Api-Signature', $signature);
    }

    /**
     * 签名计算
     *
     * @param string $signAlgorithm
     * @param mixed  $data
     * @param string $key
     *
     * @return string
     */
    private function sign($signAlgorithm, $data, $key)
    {
        return hash_hmac(substr($signAlgorithm, 5), $data, $key);
    }
}