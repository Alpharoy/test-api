<?php

namespace Urland\ApiClient;

use GuzzleHttp\Handler\CurlHandler;
use GuzzleHttp\HandlerStack;

class ClientManager
{
    /**
     * The api service configurations.
     *
     * @var array
     */
    protected $config;

    /**
     * The api services.
     *
     * @var array
     */
    protected $services;

    /**
     * Create a new api client manager instance.
     *
     * @param  array $config
     *
     * @return void
     */
    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Get a api service by name.
     *
     * @param string $name
     *
     * @return Client
     *
     * @throws \InvalidArgumentException
     */
    public function service($name)
    {
        if (isset($this->services[$name])) {
            return $this->services[$name];
        }

        return $this->services[$name] = $this->resolve($name);
    }

    /**
     * Resolve the given api service by name.
     *
     * @param  string $name
     *
     * @return Client
     *
     * @throws \InvalidArgumentException
     */
    public function resolve($name)
    {
        $globalOptions   = isset($this->config['options']) ? $this->config['options'] : [];
        $servicesOptions = isset($this->config['services']) ? $this->config['services'] : [];

        if (isset($servicesOptions[$name])) {
            return new Client(array_merge($globalOptions, $servicesOptions[$name]));
        }

        throw new \InvalidArgumentException(
            "Api service [{$name}] not configured."
        );
    }

    /**
     * Return all of the created services.
     *
     * @return array
     */
    public function services()
    {
        return $this->services;
    }
}
