<?php

namespace Urland\ApiClient;

use Illuminate\Support\ServiceProvider as BaseServiceProvider;

class ApiClientServiceProvider extends BaseServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = true;

    /**
     * Bootstrap the application urland api client.
     *
     * @return void
     */
    public function boot()
    {
        // 配置文件发布
        $configPath = __DIR__ . '/../config/api-client.php';
        $this->publishes([$configPath => $this->getConfigPath()], 'config');
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        // 配置文件
        $configPath = __DIR__ . '/../config/api-client.php';
        $this->mergeConfigFrom($configPath, 'api-client');

        // 注册api client
        $this->app->singleton('api-client', function ($app) {
            $config = $app->make('config')->get('api-client');

            return new ClientManager($config);
        });
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return ['api-client'];
    }

    /**
     * Get the config path
     *
     * @return string
     */
    protected function getConfigPath()
    {
        return config_path('api-client.php');
    }
}