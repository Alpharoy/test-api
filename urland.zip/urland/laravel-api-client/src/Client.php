<?php

namespace Urland\ApiClient;

use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Handler\CurlHandler;
use GuzzleHttp\HandlerStack;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\UriInterface;
use Urland\ApiClient\Middleware\SignMiddleware;
use Urland\ApiClient\Response\Response;
use Urland\Exceptions\Client as UrlandClient;
use Urland\Exceptions\Server as UrlandServer;

/**
 * @method Response get(string | UriInterface $uri, array $data = [], array $options = [])
 * @method Response head(string | UriInterface $uri, array $data = [], array $options = [])
 * @method Response put(string | UriInterface $uri, array $data = [], array $options = [])
 * @method Response post(string | UriInterface $uri, array $data = [], array $options = [])
 * @method Response patch(string | UriInterface $uri, array $data = [], array $options = [])
 * @method Response delete(string | UriInterface $uri, array $data = [], array $options = [])
 */
class Client
{
    /**
     * @var GuzzleClient
     */
    protected $client;

    /**
     * Client constructor.
     *
     * @param array $options
     *
     * @throws \InvalidArgumentException
     */
    public function __construct($options = [])
    {
        // 注册middleware
        $stack = HandlerStack::create(new CurlHandler());
        if (isset($options['api_sign']) ? $options['api_sign'] : false) {
            $stack->push(new SignMiddleware());
        }

        $options['handler'] = $stack;

        $this->client = new GuzzleClient($options);
    }

    /**
     * 获取原始client
     *
     * @return \GuzzleHttp\Client
     */
    public function getOriginal()
    {
        return $this->client;
    }

    /**
     * 设置原始client
     *
     * @param \GuzzleHttp\Client $client
     *
     * @return $this
     */
    public function setOriginal(GuzzleClient $client)
    {
        $this->client = $client;
        return $this;
    }

    /**
     * 格式化响应
     *
     * @param ResponseInterface $response
     *
     * @return Response
     */
    protected function formatResponse(ResponseInterface $response)
    {
        return Response::create($response);
    }

    /**
     * @param string $name
     * @param array  $arguments
     *
     * @return Response
     * @throws RequestException
     * @throws \InvalidArgumentException
     * @throws \Urland\Exceptions\BaseException
     */
    public function __call($name, $arguments)
    {
        if (count($arguments) < 1) {
            throw new \InvalidArgumentException('Magic request methods require a URI and optional data array');
        }

        $uri     = isset($arguments[0]) ? $arguments[0] : '';
        $data    = isset($arguments[1]) ? $arguments[1] : [];
        $options = isset($arguments[2]) ? $arguments[2] : [];

        // 根据不同的请求方式，合并不同的值，默认使用json
        if (isset($options['form_params'])) {
            $options['form_params'] = array_merge($options['form_params'], $data);
        } elseif (isset($options['multipart'])) {
            foreach ($data as $key => $value) {
                $options['multipart'][] = [
                    'name'  => $key,
                    'value' => $value,
                ];
            }
        } elseif (isset($options['json'])) {
            $options['json'] = array_merge($options['json'], $data);
        } else {
            $options['json'] = $data;
        }

        try {
            $response = $this->client->$name($uri, $options);
        } catch (RequestException $exception) {
            // 转换成悠然居通用异常
            if ($urlandException = $this->transformToUrlandException($exception)) {
                throw $urlandException;
            }

            throw $exception;
        }

        return $this->formatResponse($response);
    }

    /**
     * 转换成悠然居通用异常
     *
     * @param \GuzzleHttp\Exception\RequestException $exception
     *
     * @return \Urland\Exceptions\BaseException|null
     */
    protected function transformToUrlandException($exception)
    {
        // 判断是否存在悠然居的基类
        if (!$exception instanceof RequestException || !class_exists(\Urland\Exceptions\BaseException::class)) {
            return null;
        }

        // 判断是否存在响应，不存在响应证明不属于网络请求后的操作
        if (!$exception->getResponse()) {
            return null;
        }

        $response = $this->formatResponse($exception->getResponse());
        try {
            $jsonData = $response->getJson();
        } catch (\Throwable $e) {
            $jsonData = [];
        }

        $newException = null;
        $message      = isset($jsonData['message']) ? $jsonData['message'] : null;
        switch ($response->getStatusCode()) {
            case 400:
                $newException = new UrlandClient\BadRequestException($message, $exception);
                break;

            case 401:
                $newException = new UrlandClient\AuthenticationException($message, $exception);
                break;

            case 403:
                $newException = new UrlandClient\ForbiddenException($message, $exception);
                break;

            case 404:
                $newException = new UrlandClient\NotFoundException($message, $exception);
                break;

            case 422:
                $errors = isset($jsonData['errors']) ? $jsonData['errors'] : [];
                if (class_exists(\Illuminate\Support\Facades\Validator::class)) {
                    // laravel环境
                    $newException = UrlandClient\ValidationException::withMessages($errors);
                } else {
                    // 非laravel环境
                    $firstErrors = (array)reset($errors);
                    $firstError  = reset($firstErrors);

                    $newException = new UrlandClient\BaseException(422, $firstError ?: $message, $exception);
                }
                break;

            case 429:
                $newException = new UrlandClient\TooManyRequestsException($message, $exception);
                break;

            case 500:
                $newException = new UrlandServer\InternalServerException($message, $exception);
                break;

            case 503:
                $newException = new UrlandServer\ServiceUnavailableException($message, $exception);
        }

        return $newException;
    }
}