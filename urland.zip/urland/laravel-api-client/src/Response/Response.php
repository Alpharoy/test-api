<?php

namespace Urland\ApiClient\Response;

use \GuzzleHttp\Psr7\Response as GuzzleResponse;
use Psr\Http\Message\ResponseInterface;

class Response extends GuzzleResponse
{
    /**
     * @var Paginate 分页信息
     */
    protected $paginate;

    /**
     * @var RateLimit 接口请求限制信息
     */
    protected $rateLimit;

    /**
     * @var array 反序列化后的数据
     */
    protected $jsonData;

    /**
     * 创建实例
     *
     * @param ResponseInterface $response
     *
     * @return Response
     */
    public static function create(ResponseInterface $response)
    {
        return new static(
            $response->getStatusCode(),
            $response->getHeaders(),
            $response->getBody(),
            $response->getProtocolVersion(),
            $response->getReasonPhrase()
        );
    }

    /**
     * Response constructor.
     *
     * @param int         $status
     * @param array       $headers
     * @param mixed       $body
     * @param string      $version
     * @param string|null $reason
     */
    public function __construct(
        $status = 200,
        array $headers = [],
        $body = null,
        $version = '1.1',
        $reason = null
    )
    {
        parent::__construct($status, $headers, $body, $version, $reason);

        // RateLimit
        $this->rateLimit = new RateLimit($this);

        // Paginate
        $this->paginate = new Paginate($this);
    }

    /**
     * 响应json化
     *
     * @return array|null
     * @throws \InvalidArgumentException
     */
    public function getJson()
    {
        if (!is_null($this->jsonData)) {
            return $this->jsonData;
        }

        $this->jsonData = json_decode($this->getBody()->getContents(), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \InvalidArgumentException(json_last_error_msg());
        }

        return $this->jsonData;
    }

    /**
     * 分页信息
     *
     * @return Paginate
     */
    public function getPaginate()
    {
        return $this->paginate;
    }

    /**
     * 接口频率限制
     *
     * @return RateLimit
     */
    public function getRateLimit()
    {
        return $this->rateLimit;
    }
}