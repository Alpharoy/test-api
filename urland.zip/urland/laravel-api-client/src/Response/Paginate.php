<?php

namespace Urland\ApiClient\Response;

use Psr\Http\Message\ResponseInterface;

class Paginate
{
    /**
     * @var int 总条数
     */
    protected $total;

    /**
     * @var int 分页条数
     */
    protected $perPage;

    /**
     * @var int 总页数
     */
    protected $totalPage;

    /**
     * @var int 当前页数
     */
    protected $currentPage;

    /**
     * @var bool 是否存在上一页
     */
    protected $hasPrevPage;

    /**
     * @var int 上一页
     */
    protected $prevPage;

    /**
     * @var bool 是否存在下一页
     */
    protected $hasNextPage;

    /**
     * @var int 下一页
     */
    protected $nextPage;

    /**
     * Paginate constructor.
     *
     * @param ResponseInterface $response
     */
    public function __construct(ResponseInterface $response)
    {
        $headerTotalCount  = $response->getHeader('X-Page-TotalCount');
        $headerPerPage     = $response->getHeader('X-Page-PerPage');
        $headerCurrentPage = $response->getHeader('X-Page-CurrentPage');

        $this->total       = (int)reset($headerTotalCount);
        $this->perPage     = (int)reset($headerPerPage);
        $this->currentPage = (int)reset($headerCurrentPage);
        $this->totalPage   = $this->perPage ? (int)ceil($this->total / $this->perPage) : 0;

        $this->hasPrevPage = $this->currentPage > 1;
        $this->prevPage    = $this->hasPrevPage ? $this->currentPage - 1 : null;
        $this->hasNextPage = $this->currentPage < $this->totalPage;
        $this->nextPage    = $this->hasNextPage ? $this->currentPage + 1 : null;
    }

    /**
     * @return int
     */
    public function getTotal()
    {
        return $this->total;
    }

    /**
     * @return int
     */
    public function getPerPage()
    {
        return $this->perPage;
    }

    /**
     * @return int
     */
    public function getTotalPage()
    {
        return $this->totalPage;
    }

    /**
     * @return int
     */
    public function getCurrentPage()
    {
        return $this->currentPage;
    }

    /**
     * @return bool
     */
    public function isHasPrevPage()
    {
        return $this->hasPrevPage;
    }

    /**
     * @return int
     */
    public function getPrevPage()
    {
        return $this->prevPage;
    }

    /**
     * @return bool
     */
    public function isHasNextPage()
    {
        return $this->hasNextPage;
    }

    /**
     * @return int
     */
    public function getNextPage()
    {
        return $this->nextPage;
    }
}