<?php

namespace Urland\ApiClient\Response;


use Psr\Http\Message\ResponseInterface;

class RateLimit
{
    /**
     * @var int 1分钟限制多少次
     */
    protected $limit = 0;

    /**
     * @var int 当前分钟剩余多少次
     */
    protected $remaining = 0;

    /**
     * @var int 下次刷新剩余秒数
     */
    protected $retryAfter = 0;

    /**
     * @var null|\DateTime 下次重置接口限制时间
     */
    protected $resetAt = null;

    /**
     * RateLimit constructor.
     *
     * @param ResponseInterface $response
     */
    public function __construct(ResponseInterface $response)
    {
        $headerLimit      = $response->getHeader('X-RateLimit-Limit');
        $headerRemaining  = $response->getHeader('X-RateLimit-Remaining');
        $headerRetryAfter = $response->getHeader('Retry-After');
        $headerResetAt    = $response->getHeader('X-RateLimit-Reset');

        $this->limit      = (int)reset($headerLimit);
        $this->remaining  = (int)reset($headerRemaining);
        $this->retryAfter = (int)reset($headerRetryAfter);
        $resetAtTimestamp = (int)reset($headerResetAt);
        $this->resetAt    = date_create()->setTimestamp($resetAtTimestamp);
    }

    /**
     * @return int
     */
    public function getLimit()
    {
        return $this->limit;
    }

    /**
     * @return int
     */
    public function getRemaining()
    {
        return $this->remaining;
    }

    /**
     * @return int
     */
    public function getRetryAfter()
    {
        return $this->retryAfter;
    }

    /**
     * @return \DateTime|null
     */
    public function getResetAt()
    {
        return $this->resetAt;
    }
}