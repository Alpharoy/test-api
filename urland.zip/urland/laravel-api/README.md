# 悠然居laravel项目restful接口构建库

用于restful层接口提供接口构建。

### 接入步骤

1. `composer.json` 添加配置
```json
    {
      "repositories": {
        "urland/exceptions": {
          "type": "vcs",
          "url": "git@gitlab.come56.com:php-packages/exceptions.git"
        },
        "urland/laravel-api": {
          "type": "vcs",
          "url": "git@gitlab.come56.com:php-packages/laravel-api.git"
        }
      }
    }
```

2. 命令行执行引入此库
```shell
composer require urland/laravel-api
```

3. 修改 `Http\Kernel.php`，添加统一响应middleware
```php
    protected $middlewareGroups = [
        'web' => [
            ...
        ],
    
        'api' => [
            'urland.api', // <<<< 添加此行
            'throttle:60,1',
            'bindings',
        ],
    ];
```

4. 修改`RouteServiceProvider`，在所有使用此库的接口路由，使用 `api` middleware分组
```php
    /**
     * Define the "Api" routes for the application.
     * These routes are typically stateless.
     *
     * @return void
     */
    protected function mapApiRoutes()
    {
        // App调用接口
        Route::middleware('api')
            ->prefix('api')
            ->namespace($this->namespace . '\Api')
            ->group(base_path('routes/api.php'));
        
        // 内部服务调用接口
        Route::middleware('api')
            ->prefix('internal-api')
            ->namespace($this->namespace . '\InternalApi')
            ->group(base_path('routes/internal-api.php'));
    }
```

5. 在路由定义文件`api.php`和`internal-api.php`最后一行添加`apiFallback`，接管找不到路由
```php
    <?php
    Route::prefix('v1')->namespace('V1')->group(function () {
        ...
    });

    Route::apiFallback(); // <--- 务必添加这行
```

6. 修改 `Exceptions\Handler.php`，接管接口异常
```php
    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception $exception
     *
     * @return void
     * @throws Exception
     */
    public function report(Exception $exception)
    {
        if ($this->isRequestUsingApiResponse()) {
            $this->apiHandler()->report($exception);
        } else {
            parent::report($exception);
        }
    }


    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Exception               $exception
     *
     * @return mixed
     */
    public function render($request, Exception $exception)
    {
        if ($this->isRequestUsingApiResponse($request)) {
            return $this->apiHandler()->render($request, $exception);
        }

        return parent::render($request, $exception);
    }

    /**
     * 判断当前请求是否归属于Api请求
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return bool
     */
    protected function isRequestUsingApiResponse($request = null)
    {
        if (!$request) {
            if (!$this->container || !$this->container->has('request')) {
                return false;
            }
            $request = $this->container->make('request');
        }

        if ($request::hasMacro('usingApiResponse')) {
            return $request->usingApiResponse();
        }
    }

    /**
     * api异常处理
     *
     * @return \Urland\Api\Exceptions\ApiHandler
     */
    protected function apiHandler()
    {
        return $this->container->make(\Urland\Api\Exceptions\ApiHandler::class);
    }
```

7. 接入完成

### 使用说明

#### 接口授权验证

此库提供两种验证方式，分别对应两种应用场景。

1. APP用 restful 验证，driver为 `urland.token`

    此验证方式需要在用户表添加 `api_token` 字段，APP调用接口登录后，返回此字段。APP通过添加 `X-Api-Token` header即可完成身份验证。

2. 业务系统用 restful 验证，driver为 `urland.internal_token`

    此验证方式需要在用户表添加 `api_key` 与 `api_secret` 字段，通过计算签名后服务器才能正常对接口正常响应，具体签名方案请参考[客户端接口授权文档](AUTH.md)。

根据[laravel/authentication](https://laravel-china.org/docs/laravel/5.6/authentication#adding-custom-user-providers)文档配置`config/auth.php`。例：
```php
    'guards' => [
        'web' => [
            'driver' => 'session',
            'provider' => 'users',
        ],

        'api' => [
            'driver' => 'urland.token',
            'provider' => 'users',
        ],

        'internal_api' => [
            'driver' => 'urland.internal_token',
            'provider' => 'users',
        ],
    ]
 ```

需要验证的路由根据类型添加 `config/auth.php` 配置好的验证方式。例：
```php
    Route::middleware(['auth:internal_api'])->group(function () {
        Route::post('orders', 'OrderController@store');
    });
```

#### 处理成功返回响应

请参考 [Laravel Resource](https://laravel-china.org/docs/laravel/5.6/eloquent-resources/1407)

具体规则如下

| 方法名称   | 状态码 | 场景    | 返回类型 |
| --------- | ----- | ------- | ------ |
| success   | 200   | 通用    | object |
| created   | 201   | 创建资源 | object |
| accepted  | 202   | 异步任务 | object |
| noContent | 204   | 删除资源 | null   |
| paginate  | 200   | 分页数据 | array  |

#### 异常返回响应

详情参考 [接口规范](API.md)

### 客户端接入

1. 接口详细描述请看[接口规范](API.md)

2. 接口授权文档请看[接口授权](AUTH.md)