# 接口授权文档

### APP用 restful 接口

1. 通过接口获取apiToken

2. 请求时附带apiToken到 `X-Api-Token` header

3. 授权完成

### 业务系统用 restful 接口

1. 预分配apiKey与apiSecret
    
    我们预先假设：
    
       apiKey = 123456
       apiSecret = 654321

2. 必填头部

    1. `X-Api-Time` 客户端时间
    
        时间格式为[RCF3339](http://www.faqs.org/rfcs/rfc3339.html)，与服务器误差超过1分钟的请求将被拒绝。 
        
        例如： `X-Api-Time: 2018-05-03T10:55:04+08:00`
        
    2. `X-Api-Key` 业务系统身份标识
    
        由接口服务提供,请和服务提供方人员联系获取。
        
        例如：`X-Api-Key: 123456`
        
    3. `X-Api-SignatureAlgorithm` 签名方法标识
    
        目前支持 `hmac-md5` 与 `hmac-sha256`，建议使用 `hmac-sha256`。
        
        例如：`X-Api-SignatureAlgorithm: hmac-sha256`

        
    4. `X-Api-SignedHeaders` 参与签名计算的头部
    
        头部全部转为小写，并用 `;` 号分隔。注意：`x-api-key`,`x-api-signaturealgorithm`,`x-api-time` 必须加入签名。
        
        例如：`X-Api-SignedHeaders: host;user-agent;x-api-key;x-api-signaturealgorithm;x-api-time`
        
    5. `X-Api-Signature` 签名
    
        签名计算后生成的字符串，参考下面 `3. 生成签名用字符串`。

3. 生成签名用字符串 

    1. 请求方法名称
    
        请求方法全为大写的 `GET`、`POST`、`PUT`、`PATCH`、`DELETE`
    
    2. 请求路径
    
        根据 [RFC 3986](https://tools.ietf.org/html/rfc3986) 标准化 URI 路径。
        移除冗余和相对路径部分。路径中每个部分都必须为 URI 编码。
        
        例： 请求路径
        ```
        /documents and settings/
        ```
        转换后为
        ```
        /documents%20and%20settings/
        ```
        
    3. URL 查询字符串
    
        如果请求不包括查询字符串，请使用空字符串（实际上是空白行）。  
        查询字符串需按照key升序排序，同时value需要按照 [RFC 3986](https://tools.ietf.org/html/rfc3986) 规范进行编码。
        
        例： 原查询字符串为
        ```
        id=2&action=getUserList&Time=2018-03-12 12:01:04
        ```
        转换后为
        ```
        Time=2018-03-12%2012%3A01%3A04&action=getUserList&id=2
        ```
        
    4. 添加请求头部，每一个头部后面接一个换行 `\n`
    
        不同接口对于必填header要求不一，请根据各接口添加对应的header。  
        要创建规范标头列表，请将所有标头名称转换为小写形式并删除前导空格和尾随空格。例：
        
        原头部
        ```
        Host: order56.come56.com\n
        Content-Type: application/json\n
        X-Api-Time: 2018-03-12T10:05:29+08:00\n
        X-Api-Key:   OD0k3Nn5mAR4EaCI\n
        X-Api-SignatureAlgorithm: hmac-sha256
        ```
        转换后为
        ```
        content-type:application/json\n
        host:order56.come56.com\n
        x-api-key:OD0k3Nn5mAR4EaCI\n
        x-api-time:2018-03-12T10:05:29+08:00\n
        x-api-signatureAlgorithm:hmac-sha256
        ```
        
    5. 添加已签名头部
    
        要创建已签名标头列表，请将所有标头名称转换为小写形式，按字符代码对其进行排序，并使用分号来分隔这些标头名称。  
        其中 `Host`、`X-Api-Key`、`X-Api-SignatureAlgorithm`与`X-Api-Time` 必须加入签名。例：
        
        已签名标头
        ```
        host;user-agent;x-api-key;x-api-signaturealgorithm;x-api-time
        ```
        
    6. 生成请求内容(HTTP BODY)哈希字符串, 使用 [HMAC](https://en.wikipedia.org/wiki/HMAC) 签名方式
    
        伪代码如下
        ```
        //X-Api-SignatureAlgorithm 是 在请求头部中标明，具体查看 [3. 签名方法标识]
        if(X-Api-SignatureAlgorithm == 'hmac-sha256') {
            //GET_HTTP_BODY() 指获取HTTP请求的Body
            //API_SECRET  指接口密钥
            HMAC_SHA256(GET_HTTP_BODY(),API_SECRET)
        }
        ```
        
        注意：生成的签名必须以小写十六进制字符字符串形式表示。
        
    8. 进行签名
    
        按照上述流程，将组成如下的字符串：
        ```
        GET
        /documents%20and%20settings/
        Time=2018-03-12%2012%3A01%3A04&action=getUserList&id=2
        content-type:application/json
        host:order56.come56.com
        x-api-key:123456
        x-api-signaturealgorithm:hmac-sha256
        x-api-time:2018-03-08T08:26:27+00:00
        
        host;user-agent;x-api-key;x-api-signaturealgorithm;x-api-time
        a9cdee61d7c9a472e324a5ac44a368395b22f6fb463bb745d330c29065762e47
        ```
        
        使用上述字符串，进行哈希计算，伪代码如下
        ```
        if(X-Api-SignatureAlgorithm == 'hmac-sha256') {
            HMAC_SHA256(`上述字符串内容`,API_SECRET)
        }
        ```
        
    哈希字符串必须以小写十六进制字符字符串形式表示，最后生成的64位的签名字符串，附带在`X-Api-Signature`头部进行提交到服务器。

4. 发送请求到服务器

    ```
    GET /internal-api/v1/orders/stats/yesterday-total-paid?to_name=muniu HTTP/1.1
    User-Agent: GuzzleHttp/6.3.3 curl/7.29.0 PHP/7.2.5
    Host: api.order56.com
    X-Api-Time: 2018-05-03T10:55:04+08:00
    X-Api-Key: 123456
    X-Api-SignatureAlgorithm: hmac-sha256
    X-Api-SignedHeaders: host;user-agent;x-api-key;x-api-signaturealgorithm;x-api-time
    X-Api-Signature: 6a20a04afc6c444cdda28d74fb504a84b8cfa3202b10fb5e6d9c2044d26f64bb


    ```

### 签名调试

为了方便客户端调试接口签名，接口服务器可以提供签名调试接口。

Controller添加下列调试方法，此接口请勿添加auth middleware
```php
    public function debugSignature()
    {
        return $this->success(app('api.request.validator')->getSignDebugOutput());
    }
```