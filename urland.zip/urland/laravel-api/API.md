# 客户端接口规范文档

此文档用于描述接口提供内容。

### 请求方法重载

在某些特殊的环境下，无法直接发送 `PUT`、`PATCH`、`DELETE`等方法的请求，laravel提供两种方法以供重载

1. **[推荐]** 使用POST请求，添加 `X-HTTP-Method-Override` header即可重载成对应方法。

2. 使用POST请求，在url query或者request content添加 `_method` 字段即可重载方法，例如：`POST /orders/1?_method=DELETE`，相当于`DELETE /orders/1`，将会进行删除资源。

### 请求参数传递

服务器接受两种参数的传递方式。

1. **[推荐]** HTTP request content 参数传递

    设置header `Content-Type` 为 `application/json`， request content内容为json序列化后的字符串。
    
2. 常用网页form表单参数传递

    兼容大多数情况，绝大部分开源访问库均支持。

### 数据返回

#### 通用

1. 接口请求限制

服务器可以控制接口请求频率，每个接口无论成功或失败，都算作一次请求。如果服务器开启接口频率限制，所有接口都会返回接口频率相关数据的头部。

| header                | 说明             | 备注        |
| --------------------- | ---------------- | ---------- |
| X-RateLimit-Limit     | 每分钟最多请求次数 |             |
| X-RateLimit-Remaining | 每分钟请求剩余次数 |             |
| Retry-After           | x秒后可以再次请求  | 被限制后提供 |
| X-RateLimit-Reset     | 接口限制清空时间戳 | 被限制后提供 |


请求超过限制后，会返回 429 `{message: "访问过于频繁"}`。


#### 成功返回

成功返回状态码范围为 200 <= status < 300

1. success 200
 
    场景：获取/更新资源，其他情况  
    返回内容：资源本身对象
    
2. created 201

    场景：创建资源  
    返回内容：资源本身对象
       
3. accepted 202

    场景：创建异步任务  
    返回内容：空对象或任务本身对象
    
4. noContent 204

    场景：删除资源  
    返回内容：null
    
5. paginate 200

    场景：资源列表  
    返回内容：资源对象数组  
    header附加内容：
    
    | header             | 说明                        |
    | ------------------ | --------------------------- |
    | X-Page-TotalCount  | 总条数                       |
    | X-Page-CurrentPage | 当前页数                     |
    | X-Page-PerPage     | 单页数量                     |
    | Link               | 首页/尾页/上一页/下一页访问URL |
    
如场景有重叠，请按照序号依次匹配。

#### 异常返回

此库已内置两类异常覆盖业务场景。

1. `Urland\Exceptions\Client` 异常

    此异常类型一般由于客户端错误调用造成，需记录到日志以便分析造成原因。
    
    1. `BadRequestException` 400
        
        通用异常类型，如果无法归类到其他异常可以使用此异常。如某个场景使用此异常过多，根据使用情况添加到库中。
        
    2. `AuthenticationException` 401
    
        需要登录，一般用于接口需要客户端登录，但客户端没有登录就调用接口。
        
    3. `ForbiddenException` 403
    
        权限不足，一般用于客户端已经登录，但所登录的用户权限不足以调用某接口。
        
    4. `NotFoundException` 404
        
        找不到资源，一般用于获取/修改资源时，没有提供正确的资源标识(id)导致。
        
    5. `ValidationException` 422
    
        请求参数校验失败，一般用于客户端参数提交不完整或提交格式错误。此异常会额外返回errors字段，以便提醒客户端哪些字段没通过验证。
        
    6. `TooManyRequestsException` 429
    
        请求过于频繁，一般由于客户端调用接口频率过高造成。
        

2. `Urland\Exceptions\Server` 异常

    此异常类型一般由于服务器错误造成，需即时通知运维人员进行处理。
    
    1. `InternalServerException` 500
    
        除Client异常以外的情况，均会抛出此异常。一般不需要业务系统主动抛出。
        
    2. `ServiceUnavailableException` 503
        
        预期的服务器暂不可用异常，一般用于服务器维护时抛出。此异常无需通知运维。
        

根据以上异常，一般返回的内容为：
```json
    {"message": "访问过于频繁"}
```

所有异常消息客户端可直接显示，但更推荐针对状态码进行特殊处理。