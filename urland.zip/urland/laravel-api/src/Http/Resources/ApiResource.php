<?php

namespace Urland\Api\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ApiResource extends JsonResource
{
    /**
     * The "data" wrapper that should be applied.
     *
     * @var string
     */
    public static $wrap = null;

    /**
     * Response default headers.
     *
     * @var array
     */
    protected $headers = [];

    /**
     * Options for encoding data to JSON.
     *
     * @var int
     */
    protected $encodingOptions = 0;

    /**
     * Create new anonymous resource collection.
     *
     * @param  mixed $resource
     *
     * @return static[]
     */
    public static function collection($resource)
    {
        return new AnonymousResourceCollection($resource, get_called_class());
    }

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return array
     */
    public function toArray($request)
    {
        $array = parent::toArray($request);

        return $array;
    }

    /**
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function toResponse($request)
    {
        return (new ResourceResponse($this))->toResponse($request, $this->headers, $this->encodingOptions);
    }
}
