<?php

namespace Urland\Api\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ApiRequest extends FormRequest
{
    /**
     * 请求当前页码
     *
     * @param mixed $default
     *
     * @return integer|mixed
     */
    public function getCurrentPage($default = null)
    {
        return $this->header('X-Page-CurrentPage', $default);
    }

    /**
     * 每页条数
     *
     * @param mixed $default
     *
     * @return integer|mixed
     */
    public function getPerPage($default = null)
    {
        return $this->header('X-Page-PerPage', $default);
    }
}