<?php

namespace Urland\Api\Http\Middleware;

use Urland\Api\Http\ApiResponse;
use Urland\Exceptions\Server\InternalServerException;

class UnifiedResponse
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     *
     * @return mixed
     */
    public function handle($request, \Closure $next)
    {
        return $next($request);
    }
}