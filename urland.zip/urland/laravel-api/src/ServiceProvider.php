<?php

namespace Urland\Api;

use Illuminate\Support\ServiceProvider as BaseServiceProvider;
use Urland\Api\Auth\InternalTokenGuard;
use Urland\Api\Auth\TokenGuard;
use Urland\Exceptions\Client\BadRequestException;
use Urland\Api\Http\Requests\ApiRequestValidator;
use Urland\Api\Http\Middleware\UnifiedResponse;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * The application's route middleware.
     *
     * These middleware may be assigned to groups or used individually.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'urland.api' => \Urland\Api\Http\Middleware\UnifiedResponse::class,
    ];

    /**
     * Bootstrap the application urland api.
     *
     * @return void
     */
    public function boot()
    {
        // 注册中间件
        $this->registerMiddlewares();
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        // 注册验证扩展
        $this->registerAuthGuards();

        // API用方法扩展
        $this->extendFoundation();

        // 注册api用签名
        $this->app->singleton('api.request.validator', function ($app) {
            return new ApiRequestValidator($app);
        });
    }

    /**
     * 注册中间件
     */
    protected function registerMiddlewares()
    {
        $router = $this->app['router'];
        foreach ($this->routeMiddleware as $key => $middleware) {
            $router->aliasMiddleware($key, $middleware);
        }
    }

    /**
     * 注册提供的验证方式
     */
    protected function registerAuthGuards()
    {
        // 司机token验证
        \Auth::extend('urland.token', function ($app, $name, array $config) {
            return new TokenGuard(\Auth::createUserProvider($config['provider']), $app['request']);
        });

        // 内部服务token验证
        \Auth::extend('urland.internal_token', function ($app, $name, array $config) {
            return new InternalTokenGuard(\Auth::createUserProvider($config['provider']), $app['request']);
        });
    }

    /**
     * 框架功能扩展
     */
    protected function extendFoundation()
    {
        // 增加是否使用了API统一响应的middleware方法
        \Request::macro('usingApiResponse', function () {
            static $usingApiResponse = null;

            if (is_null($usingApiResponse)) {
                // 默认没有使用
                $usingApiResponse = false;

                if ($route = $this->route()) {
                    // 解析middleware，判断是否存在UnifiedResponse这个Middleware
                    foreach (app('router')->gatherRouteMiddleware($route) as $middleware) {
                        list($class) = explode(':', $middleware);

                        if (UnifiedResponse::class === $class) {
                            $usingApiResponse = true;
                            break;
                        }
                    }
                }
            }

            return $usingApiResponse;
        });

        // 增加针对api的fallback
        \Route::macro('apiFallback', function () {
            $placeholder = 'fallbackPlaceholder';

            $action = function () {
                throw new BadRequestException('请求接口不存在');
            };

            return $this->addRoute(
                self::$verbs, "{{$placeholder}}", $action
            )->where($placeholder, '.*')->fallback();
        });
    }
}